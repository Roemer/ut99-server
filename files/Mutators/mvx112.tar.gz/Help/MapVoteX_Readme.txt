MapVoteX Readme
===============

Install on Server:
ServerPackages=MapVoteX112

Startup: DM-Tutorial?Game=Botpack.DeathMatchPlus?Mutator=MapVoteX112.MapVoteX

Special Info on MapFolder= and how MapVoteX works and using the DM-Tutorial.unr map at startup.

MapVoteX detects which game is running by the GameName and not the GameClass as other vote applications use.
This enables MapVoteX to use many games, although we have settled on 200 games which should suffice any Admin.
These 200 Games can all have the same GameClass etc as long as the GameNames are different.
It is also advisable to set the bGameName=True in each game allowing MapVoteX to write your selected GameName to memory and display it on the clients Scoreboard.

Each of the 200 games can have their own set of maps, this allows the Admin to have different DM maps for all different types of games that all use DM maps for instance.
To do this is easy and MapVoteX will take care of the paths needed for the seperate Game Map Folders.
Each CustomGameConfigs has a MapFolder= where the Admin can point to the specific MapFolder.
For instance it is probably best to make sub folders off the current Maps folder where you will store maps for a specific game.
Lets take the game 'Sniper Arena DeathMatch' for an example, here ytou can have a map folder called Sniper where all the DM maps for this specific game go and add in the MapFolder=Maps/Sniper
MapVoteX will now automatically set the paths in the ini file to Paths=..Maps/Sniper/*.unr for you.

It is at this point we advise you to remove ALL maps from your servers current Maps folder and put them in special folders for the various games which may mean duplicating several maps but with todays huge hard drives that is not a problem.
Maps that MUST remain in the Maps folder are: DM-Tutorial.unr, Entry.unr and CityIntro.unr.

It is also very important that the server startup commandline start with a DM-Tutorial.unr map, this tells MapVoteX that it is a server startup and will then switch to the correct game that is listed in MVGameName=
Example:
UCC Server DM-Tutorial?Game=Botback.DeathMatchPlus?Mutator=MapVoteX112.MapVoteX Log=Server.log
If now for example the MVGameName=Capture the Flag regardless of what the startup command line is, provided it starts with a DM-Tutorial.unr map, MapVoteX will auto start Capture the flag with the map in it's DefaultMap=

[MapVoteX112.MapVoteX]

bAutoOpen=True
If you want the mapvote menu to auto popup at game end, set this to True.

bAllowMidGameVoting=True
If voting during the game is allowed.

bDebugMode=False
This is for Admins only as it writes a lot of stuff to the log to try and diagnose a possible problem.

bUseCommandOptions=True
MapVoteX offers most the ! commands needed and this will enable them.
Just check that some other mod does not also have them before enabling.

bMajorityPlayerVote=False
Normally at game end and during voting the game will wait till all the players have voted and the map with the most votes wins.
However with this set to True, the vvote will be decided once the majority of players have voted.

bEnableSplashLogo=True
This will allow the loading of a .utx file for the server logo at game start.

bEnableWelcomeMenu=True
This will show a Welcome screen in the Mapvote Menu where a custom .utx file can be loaded for server or game advertising etc.

bShowWelcomeFirst=False
During the game, if a players calls for the Vote Menu, the Welcome screen will show first.

bSortCustomGameList=False
Setting this to True will alphabetically sort the Games in the vote list.

EmptyServerSwitchTimeMins=20
The time in minutes the server will stand empty if there are no players before it switches to the default Game/Map or Random map.

bEmptyServerSwitchMap=False
If this is set to True and there are no players for a EmptyServerSwitchTimeMins then the server will switch to the default Game and default Map.

bEmptyServerRandomMap=False
if bEmptyServerSwitchMap=True and bEmptyServerRandomMap=True then every EmptyServerSwitchTimeMins the server will switch to a random map on the current game.

bDoubleClickVoting=False
When voting for a map you can double click it rather than clicking the Vote button.
NB: On some computers this may cause double voting due to keybounce and is probably best left False;

GameStartVoteDelay=15
If mid game voting is permitted, the delay time it takes before the vote menu can be opened from the start of the game.

VoteTimeLimit=60
At game end, the total voting time allowed before a random map is used.

PopupWindowDelay=10
At game end, the time it takes before the vote menu pops up.

RepeatLimit=5
The number of games that go by before the map becomes available again to vote.

DefaultCustomGameNum=0
This is a very important setting and points to the CustomGame[x] that you wish to be your default game.
This is also the game that will be chosen when the server starts up with the DM-Tutorial.unr map.

bEnableServerPackages=False
This enables MapVoteX to switch in and out the necessary ServerPackages and ServerActors as needed for each game type.

bClearAllPackageActors=False
This should only be set to True in the game by an Admin using the mutate command:
Mutate MapvoteX ClearPackages
This will clear all current ServerPackages and Actors from your server's UT.ini file and replace them with fresh ServerPackages
and Actors from the MapvoteX.ini file if available.
bClearAllPackageActors will then automatically be set to False.
This should be done only on rare occasions.

MaintenanceServerName=
MaintenancePassword=
In the Admin Menu, is a Maintenance button, which just basically restarts the server with a Specific ServerName, a GamePassword and 1 Bot which can be used by the Admin to inspect various things.
Clicking the button a second time puts everything back to normal.
NB: The server should not be exitted or stopped during a Maintenance mode.

ServerGamePassword=
If you wish to run a private server with a password for the players, add that password here, or leave it blank.

ServerIpAddress=
This was added as some servers do not show an IP address for some reason, so just add it here with the port.
Example: ServerIpAddress=152.111.192.238:7777
Basically in the Info or Welcome screens a Add to Favourites button will appear if this information is present.

ServerNameTitle=""
This acts as a Servername Prefix to the Servername= in each CustomGame.

DefaultMutators=
Add whatever mutators that will load with every game here separated by commas.
Example: DefaultMutators=SmartDM105.SmartDM,UTbots.UTBots,UTLogit.Logit

DefaultSettings=
Add whatever mutators that will load with every game here separated by commas.
Example: DefaultSettings=MaxPlayers=24,FragLimit=30,TimeLimit=20,GameSpeed=1.15


CustomGames
===========

Here MapVoteX offers 200 possible different game types which can all use the same GameClass if need be as MapVoteX goes by Game Names and as long as they are names all different everything will work as required.
CustomGame[x]=
bUse=False
This should be set to true if you want it listed in the Vote Menu provided all the parameters are filled in.

MapFolder=""
This should have the folder name of where the maps are for this game.
Example: MapFolder="Maps/DM1"

DefaultMap=""
This is the map which will start the game when it is voted by the Admin and should be a popular map.
Example: DefaultMap="DM-Deck16]["

GameName=""
Here you add a Game name  of your choice.
Example: GameName="DeathMatch Killer"

GameClass=""
The actual Game class for this game as required.
Example: GameClass="Botpack.DeathMatchPlus"

Mutators=""
Whatever mutators that may be required for this game.
Example: Mutators="Jopack.RocketArena,UTBots.UTBots"

Settings=""
Whatever settings that may be required for this game.
Example: Settings="InitialBots=3,Difficulty=4,FragLimit=10,TimeLimit=7,MinPlayers=4"

ServerPackages=""
Any ServerPackages that this game may have.

ServerActors=""
Any ServerActors that this game may have.

ServerName=""
A special ServerName that this game requires.

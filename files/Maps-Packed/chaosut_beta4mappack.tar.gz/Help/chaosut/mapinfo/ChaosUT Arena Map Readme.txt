General Information
---------------------------------------------------
Special Arena Maps have been developed for ChaosUT.
Guess what? This is one of those maps.  This map is
for use with Chaos UT (CUT) mutators, but this map 
is not limited to CUT mutators.  Default UT Arena 
mutators can be used with this map.

CUT Arena Maps are generally marked with DM-CUTA_
instead of the default DM-CUT_ prefix for regular
CUT DM maps.  However, the CUT mutators are not 
limited for use with only CUT Arena Maps.  CUT 
mutators can be used with Regular UT or CUT map.

CUT comes with some special mutators/gametypes 
for its weapons. Theses include Sword Arena (SA), 
Team SA, Regular Crossbow Arena (CA), Poison CA, 
and Explosive CA.


Important Note
---------------------------------------------------
This arena map does not contain any weapons and 
therefore you need to select with mutator you want
to use with this map.


Starting The Match
---------------------------------------------------
Start a practice session and select this map from 
the map list.  Next, Select the which Arena 
mutator/gametype you would like to use.  If you 
want to add another twist to gameplay, add in the 
default UT relics.

Since players start with weapons and don't have to 
go looking for any weapons, it is suggested that 
you turn off CUT Spawn Protection.  This can be 
changed by going to the Chaos UT Config under the 
Mod menu. (Don't forget to turn it back on when you
change to another map)
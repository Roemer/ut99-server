--------------------------------------------------------------
DM-FNB-HyperFrag
 by Rob 'FraGnBraG' Burns
 ReadMe File for Unreal Tournament
 Release Date: November 02, 2011
--------------------------------------------------------------
TITLE:          DM-FNB-HyperFrag (UTR)
Filename:      DM-FNB-HyperFrag.zip
Version:        1.00 FINAL
Player load:    8 - 16
Last Update:    November 02, 2011
Author:         Rob 'FraGnBraG' Burns

--------------------------------------------------------------
 IMPORTANT NOTES:
--------------------------------------------------------------
INTENDED UT RENDERING DRIVER : 
OpenGL (UTGLR32) or later 
Late model D3D driver should be ok 

INTENDED UT BRIGHTNESS SETTING : 
5/10 (Press "F11" key when in-game).

eMail Address: Fragnbrag@gmail.com

Website: http://sites.google.com/site/fragnbrag/

DESCRIPTION:  

Large DM / TDM map based on DOM-FNB-HyperFrag, good for 8 -16 players.
Features UTR XPickups from UT99.org.  In addition to XPickup Doublespeed 
powerups, this map includes some Wildcard pickup bases for a random variety 
of goodies.  In a FFA match with 16 masterful BOTs it can be tough to stay on 
top (or even to keep up) Hope you enjoy the map!

--------------------------------------------------------------
 Play Information
--------------------------------------------------------------
Game: Unreal Tournament
Level Name: DM-FNB-HyperFrag
Game Type: UT-DM / TDM
Botmatch: Yes
Single Player: No
Teamplay: Yes
Difficulty Settings: Only For Bots
Custom Textures: Lots - See MyLevel
New Sounds: No
Custom Music: Sub2.umx
Mods/Mutators: UTR XPickups from UT99.org 
# of Players: 8 - 16 (or more if you need extra killin' ;)

--------------------------------------------------------------
 Inventory
--------------------------------------------------------------
plenty...

--------------------------------------------------------------
 Construction
--------------------------------------------------------------
Base: Original Map

Build Time:  For the DOM map, I removed one of the bases, made a 
few modifications, added xpickups, adjusted the path network, tweaked 
placements etc, tested  tested tested - 4 hours. For the DM, time was
spent mainly testing and tweaking bots, powerups - about 3 hours.

Editor(s) Used: UnrealEd2, PhotoShop

--------------------------------------------------------------
Mods/Mutators
--------------------------------------------------------------
UTR XPickups from UT99.org - This is a very cool mod which 
enhances the pickups (new skins, sounds and effects) and 
adds pickup chargers ala UT3! 

Check out http://www.ut99.org/utr/index.html for more info 
on XPickups and download the UT99.org Community Map Pack 2
for amazing professional-quality UT99 maps and see the full 
effects of XPickups!

--------------------------------------------------------------
 Installation
--------------------------------------------------------------
Unzip the DM-FNB-HyperFrag.zip file and place *.unr in your
Unreal Tournament/Maps directory, then either doubleclick on it,
or type 'open DM-FNB-HyperFrag' in the console or select the Map
in  a Botmatch or an Internet game.

*.unr files go in Maps/
*.utx files go in Textures/
*.umx files go in Music/
*.uax files go in Sounds/
*.u *.int *.ini files go in System/

--------------------------------------------------------------
 Additional files:
--------------------------------------------------------------
XPickups.u, XPickups.int, XPickups.ini  
Sub2.umx

--------------------------------------------------------------
CREDITS:
--------------------------------------------------------------
Please see the readme file for the CTF-FNB-HyperFrag map 
for the original CREDITS.

Many thanks to UT99.org and the makers of UTR XPickups and  
especially the XReplacer mutator :) 

Cheers
FNB

--------------------------------------------------------------
 Other Levels By Author:
--------------------------------------------------------------
Lots... For more info on FNB mapping projects, please visit 

	http://sites.google.com/site/fragnbrag/.

--------------------------------------------------------------
 Copyright / Permissions
--------------------------------------------------------------
=======================================
This level is copyright by Rob 'FraGnBraG' Burns 2005 - 2011.
Authors may NOT use this level as a base to build additional levels
without explicit permission from the Original Author (ME!!)
=======================================
You are NOT allowed to commercially exploit this level, i.e. put it
on a CD or any other electronic medium that is sold for money without
my explicit permission! You MAY distribute this level through any
electronic network (internet
(web/ftp), FIDO, local BBS etc.), provided you include this file and
leave the archive intact.

UNREAL (c)1998 Epic Megagames, Inc. All Rights Reserved. Distributed
by GT Interactive Software, Inc. under license. UNREAL and the UNREAL
logo are registered trademarks of Epic Megagames, Inc. All other
trademarks and trade names are properties of their respective owners.
UNREAL TOURNAMENT (c)1999 Epic Megagames, Inc. All Rights Reserved.
Distributed by GT Interactive Software, Inc. under license.
UNREAL TOURNAMENT and the UNREAL TOURNAMENT logo are registered
trademarks of Epic Megagames, Inc. All other trademarks and trade
names are properties of their respective owners.

This ReadMe is BASED ON THE Template generated by UTReadMeTemplate.cgi
created by FuzzBuster{G3} for NaliCity.

--------------------------------------------------------------
 COMMENTS AND SUGGESTIONS ARE ALWAYS WELCOME....
 HOPE YOU ENJOY THE MAP!
--------------------------------------------------------------
FNB, November 02, 2011

EOF


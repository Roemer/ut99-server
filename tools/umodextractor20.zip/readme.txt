Unreal Tournament UMOD Extractor v2.0
-------------------------------------

This tool allows you to extract files from an UMOD file containing Unreal Tournament packages and files.

* UMODExtractor.exe is an independent tool

* UMODExtractorCM.dll is a context menu shell extension that adds 
  an extract menu option to shell context menu of umod files.
  To Install this shell extension you have to put the dll in some
  directory in your path (the Windows directory for example) and
  execute the UMODextractorCM.reg file to add some registry entries.
  If you already have an old version installed, close all file explorer
  windows and update the DLL using COPY from a command prompt window 
  (DOS shell).

http://www.acordero.org/UTilities

History:

2.0 - Added contents list and extraction of selected files.

1.0 - Initial version
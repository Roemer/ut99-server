<?php

if (!isset($argv[1])) {
	die('Usage: '.basename($argv[0], '.php').' module.u[tx] [--scan]'.PHP_EOL);
}
$dbg = false;

$metas = array(
	'Botpack.Bot',
	'Botpack.TDMmaplist',
	'Botpack.ASMapList',
	'Botpack.DOMMapList',
	'Botpack.CTFMapList',
	'Botpack.TDKMapList',
	'Botpack.TournamentGameInfo',
	'Botpack.TournamentPlayer',
	'Botpack.TournamentWeapon',
	'BotPack.VoiceBoss',
	'BotPack.VoiceMale',
	'BotPack.VoiceFemale',
	'Core.Commandlet',
	'Engine.Console',
	'Engine.GameInfo',
	'Engine.MapList',
	'Engine.Mutator',
	'Engine.Weapon',
	'UMenu.UMenuModMenuItem',
	'UTBrowser.UTBrowserServerListWindow',
	'UTMenu.UTExtraKeyBindings',
	'UWindow.UWindowLookAndFeel',
	'UnrealShare.Bots',
	'UnrealShare.SinglePlayer',
	'UnrealShare.UnrealiPlayer',
);
$end = array();
foreach ($metas as $meta) {
	$end[strtolower($meta)] = $meta;
	$parts = explode('.', $meta);
	$end[strtolower($parts[1])] = $meta;
}
$parents =
array ( // Botpack
  'ctfmaplist' => 'maplist',
  'ctfdefaultmaplist' => 'maplist',
  'femalebotplus' => 'humanbotplus',
  'commander' => 'tournamentplayer',
  'deathmatchplus' => 'tournamentgameinfo',
  'ctfgame' => 'teamgameplus',
  'enforcer' => 'tournamentweapon',
  'challengeintro' => 'deathmatchplus',
  'humanbotplus' => 'bot',
  'impacthammer' => 'tournamentweapon',
  'warheadlauncher' => 'tournamentweapon',
  'chainsaw' => 'tournamentweapon',
  'voicefemaletwo' => 'voicefemale',
  'voicefemaleone' => 'voicefemale',
  'dommaplist' => 'maplist',
  'doubleenforcer' => 'enforcer',
  'ut_flakcannon' => 'tournamentweapon',
  'ut_eightball' => 'tournamentweapon',
  'ut_biorifle' => 'tournamentweapon',
  'laddertransition' => 'utintro',
  'utintro' => 'tournamentgameinfo',
  'trophygame' => 'utintro',
  'lastmanstanding' => 'deathmatchplus',
  'translocator' => 'tournamentweapon',
  'trainingdom' => 'domination',
  'trainingdm' => 'deathmatchplus',
  'trainingctf' => 'ctfgame',
  'trainingas' => 'assault',
  'tournamentweapon' => 'weapon',
  'tournamentmale' => 'tournamentplayer',
  'tournamentgameinfo' => 'gameinfo',
  'tournamentfemale' => 'tournamentplayer',
  'tmale2bot' => 'malebotplus',
  'tmale2' => 'tournamentmale',
  'tmale1bot' => 'malebotplus',
  'tmale1' => 'tournamentmale',
  'tfemale2bot' => 'femalebotplus',
  'tfemale2' => 'tournamentfemale',
  'tfemale1bot' => 'femalebotplus',
  'tfemale1' => 'tournamentfemale',
  'teamgameplus' => 'deathmatchplus',
  'tdmsmallmaplist' => 'maplist',
  'tdmmediummaplist' => 'maplist',
  'tdmmaplist' => 'maplist',
  'tdmlargemaplist' => 'maplist',
  'tdmdefaultmaplist' => 'maplist',
  'tdkmaplist' => 'maplist',
  'tdkdefaultmaplist' => 'maplist',
  'tdarkmatch' => 'deathmatchplus',
  'tbossbot' => 'malebotplus',
  'tboss' => 'tournamentmale',
  'ladderloadgame' => 'utintro',
  'supershockrifle' => 'shockrifle',
  'sniperrifle' => 'tournamentweapon',
  'skaarjbot' => 'bot',
  'shockrifle' => 'tournamentweapon',
  'domdefaultmaplist' => 'maplist',
  'domination' => 'teamgameplus',
  'voicemaletwo' => 'voicemale',
  'ripper' => 'tournamentweapon',
  'voicemaleone' => 'voicemale',
  'voicebotboss' => 'voiceboss',
  'assault' => 'teamgameplus',
  'asmaplist' => 'maplist',
  'asdefaultmaplist' => 'maplist',
  'pulsegun' => 'tournamentweapon',
  'laddernewgame' => 'utintro',
  'malebotplus' => 'humanbotplus',
  'minigun2' => 'tournamentweapon',
) +
array ( // MultiMesh
  'tskaarjbot' => 'custombot',
  'tskaarj' => 'customplayer',
  'tnalibot' => 'custombot',
  'tnali' => 'customplayer',
  'tdmbonuspackmaplist' => 'maplist',
  'tcowbot' => 'custombot',
  'tcow' => 'customplayer',
  'skaarjvoice' => 'voicemaletwo',
  'nalivoice' => 'voicemaletwo',
  'multimeshmenu' => 'umenumodmenuitem',
  'customplayer' => 'tournamentmale',
  'custombot' => 'malebotplus',
  'ctfbonuspackmaplist' => 'maplist',
  'cowvoice' => 'voicemaletwo',
) +
array ( // SkeletalChars
  'warboss' => 'skeletalplayer',
  'xanmk2' => 'skeletalplayer',
  'xanmk2bot' => 'skeletalbot',
  'skeletalbot' => 'humanbotplus',
  'skeletalplayer' => 'tournamentplayer',
  'warbossbot' => 'skeletalbot',
) +
array();

//$parents = array(); // tmp

if (isset($argv[2]) && $argv[2] == '--scan') {
	$system = dirname($argv[1]);
	if (strtolower(basename($system)) == 'textures' &&
		file_exists(dirname($system).'/System')) {
		$system = dirname($system).'/System';
	}
	foreach (glob($system.'/*.u') as $u) {
		get_classes($u);
	}
}

foreach (glob($argv[1]) as $u) {
	$out = array();
	if (substr(strtolower($u), -4) == '.utx') { // skins?
		$package = basename($u, '.utx');
		if (!stripos($package, 'skins')) continue;
		$int = substr($u, 0, -4).'.int';

		if (strtolower(basename(dirname($int))) == 'textures' &&
			file_exists(dirname(dirname($int)).'/System')) {
			$int = dirname(dirname($int)).'/System/'.basename($int);
		}

		$names = get_package_names($u);
		var_export($names);
		$skins = array();
		$cows = array();
		foreach ($names as $low => $name) {
			if ((preg_match('@^[A-Za-z_]{4}[45][A-Za-z_]@i', $name) && isset($names[substr($low, 0, 4).'1'])) ||
				(preg_match('@^[A-Za-z_]{4}[123]$@i', $name) && isset($names[$low.'t_0']) && isset($names[$low.'t_1']) && isset($names[$low.'t_2']) && isset($names[$low.'t_3']))) {
				$name = substr($name, 0, 4);
				$skins[$name] = $name;
			} elseif (isset($names[strtolower($name).'face'])) {
				$cows[$name] = $name;
			}
		}
		if ($skins) {
			$pat = '@^('.implode('|', $skins).')(\d)(.*)$@i';
			$used = array();
			foreach ($names as $name) {
				if (!preg_match($pat, $name, $matches)) continue;
				$descr = '';
				if ($matches[2] == '1' && $matches[3] == '') {
					$descr = trim(substr($package, stripos($package, 'skins') + 5), '_');
					if (!$descr) $descr = substr($package, 0, stripos($package, 'skins'));
					if (count($skins) > 1) $descr .= '.'.$matches[1];
				}
				if ($matches[2] != '1' && strtolower(substr($matches[3], 0, 2)) != 't_') {
					if (!isset($used[$matches[1].'_'.$matches[3]])) {
						$descr = $matches[3];
						$used[$matches[1].'_'.$matches[3]] = true;
					}
				}
				if ($descr) $descr = ',Description="'.$descr.'"';
				$out[] = 'Object=(Name='.$package.'.'.$name.',Class=Texture'.$descr.')';
			}
		}
		if ($cows) {
			$pat = '@^('.implode('|', $cows).')$@i';
			foreach ($names as $name) {
				$descr = '';
				if (strtolower(substr($name, 0, 6)) != 't_cow_') {
					if (!preg_match($pat, $name, $matches)) continue;
					$descr = $name;
				}
				if ($descr) $descr = ',Description="'.$descr.'"';
				$out[] = 'Object=(Name='.$package.'.'.$name.',Class=Texture'.$descr.')';
			}
		}
	} else {
		if (substr(strtolower($u), -2) != '.u') {
			echo 'File extensions must be .u or .utx: "'.$u.'"!'.PHP_EOL;
			continue;
		}
		$package = basename($u, '.u');
		$int = substr($u, 0, -2).'.int';

		$classes = get_classes($u);
		if (!$classes) {
			echo 'Sources not found inside "'.$u.'" file!'.PHP_EOL;
			continue;
		}

		foreach ($classes as $low => $class) {
			$meta = get_meta($low);
			if (!$meta) continue;
			$full = $package.'.'.$class;
			$descr = strtolower($package) == strtolower($class) ? $class : $full;
			if ($dbg) echo $full.' => '.$meta.PHP_EOL;
			$out[] = 'Object=(Name='.$full.',Class=Class,MetaClass='.$meta.',Description="'.$descr.'")';
		}
	}
	echo 'Source: '.$u.PHP_EOL;
	echo 'Destination: '.$int.PHP_EOL;
	if (!$out) {
		echo 'Nothing found.'.PHP_EOL;
	} else {
		echo PHP_EOL.'Found '.count($out).' objects.'.PHP_EOL.PHP_EOL;
		echo implode(PHP_EOL, $out).PHP_EOL;
		$data = '[Public]'.PHP_EOL.implode(PHP_EOL, $out).PHP_EOL;
		if (file_exists($int)) {
			echo PHP_EOL.'Destination file already exists!'.PHP_EOL.PHP_EOL.
				'Generated content:'.PHP_EOL.$data.PHP_EOL.
				'Exists content:'.PHP_EOL.file_get_contents($int).PHP_EOL;
		} else {
			file_put_contents($int, $data);
		}
	}
	echo PHP_EOL;
}
if (false) {
	var_export($classes);
	foreach ($classes as $low => $parent) {
		if (!get_meta($low)) {
			unset($classes[$low]);
		} else {
			$classes[$low] = $parents[$low];
		}
	}
	var_export($classes);
}

function get_classes($u) {
	global $parents;
	$classes = array();
	if (preg_match_all('@class\s+(\S+)\s+(extends|expands)\s+([^\s;]+)@i', file_get_contents($u), $matches)) {
		foreach ($matches[1] as $index => $class) {
			$parent = $matches[3][$index];

			$low = strtolower($class);
			$parent_low = strtolower($parent);
			$classes[$low] = $class;
			$parents[$low] = $parent_low;
		}
	}
	return $classes;
}

function get_meta($class) {
	global $parents, $end;
	if (!isset($parents[$class])) return false;
	$parent = $parents[$class];
	if (isset($end[$parent])) return $end[$parent];
	return get_meta($parent);
}

function get_package_names($package) {
	$header = file_get_contents($package, false, null, 0, 20);
	$header = unpack('Vsignature/Vversion/Vflags/Vcount/Voffset', $header);
	$data = file_get_contents($package, false, null, $header['offset']);
	$cnt = $header['count'];
	$start = $header['version'] < 64 ? 0 : 1;
	$out = array();
	while (strlen($data) && count($out) < $cnt) {
		$data = substr($data, $start);
		$data = explode("\0", $data, 2);
		$out[] = $data[0];
		$data = substr($data[1], 4);
	}
	return array_combine(explode('|', strtolower(implode('|', $out))), $out);

}
Script for make .INT file from .U or .UTX (skins) file.

In UT2004 present command for make .INT for exists .U file: https://wiki.beyondunreal.com/Legacy:DumpIntCommandlet

In UT99 nothing similar I not found. So I create script for this.

Script written in php.
Usage:
Unpack zip into UT root folder (near System dir).
Run in console (in this dir):
php dumpint.php System\some_file.u
for create System\some_file.int for package some_file.u.
or 
php dumpint.php Textures\some_skins.utx
for create System\some_skins.int for skin textures in some_skins.utx.

If package some_file.u based on other packages, then you must specify option "--scan" at the end:
php dumpint.php System\some_file.u --scan
it is lead to full scan of all .U files in System folders.

You can use wildcard in file name. For example 
php dumpint.php System\*.u
php dumpint.php Textures\*skins*.utx

.UTX must contains "skins" in name or not be processed.
Some skins do not fit this rule, so you can rename it, make .INT file, and rename it back, also with rename created .INT file.

.U file supported all with sources of scripts. If sources stripped, then this tool not work.
.UTX skins support for standard models, and for any custom models which follow same rules for name textures for skins.
If model use custom rules, then this tool can not generate .INT file.

If .INT file exists then dumpint not overwrite it. Instead of this, it show generated out for comparsion with exists file.
For example:
Destination file already exists!

Generated content:
[Public]
Object=(Name=Arumi.ArumiBot,Class=Class,MetaClass=Botpack.Bot,Description="Arumi.ArumiBot")
Object=(Name=Arumi.Arumi,Class=Class,MetaClass=Botpack.TournamentPlayer,Description="Arumi")

Exists content:
[Public]
Object=(Name=Arumi.ArumiBot,Class=Class,MetaClass=Botpack.Bot,Description="Arumi.ArumiBot")
Object=(Name=Arumi.Arumi,Class=Class,MetaClass=Botpack.TournamentPlayer,Description="Arumi")
You must delete .INT file manually if you want store generated content, no overwrite option exists.

This tool can be useful for use custom mutators or skins from any server.